# Kivikylän Areenan paikkakarttademo

Avaa paikallisesti:

```bash
cd /home/nabil/areena-paikkakartta-demo
python3 -m http.server 4173 --bind 127.0.0.1
```

Selainosoite: `http://127.0.0.1:4173/`

## Upotus lippukauppaan

Kun tiedosto on julkaistu HTTPS-osoitteeseen:

```html
<iframe
  src="https://LIPPUKAUPAN-DOMAIN/seatmap/index.html"
  title="Valitse paikat Kivikylän Areenalta"
  style="width:100%;min-height:780px;border:0"
  loading="lazy"
></iframe>
```

Tuotannossa `postMessage`-kutsujen kohde `'*'` vaihdetaan lippukaupan tarkaksi originiksi.

## Upottavan sivun vastaanottamat tapahtumat

Paikkavalinnan muuttuessa:

```js
{
  type: 'kivikyla-seatmap:selection',
  eventId: 'RAHINA-MMA-DEMO',
  seats: [{ id, section, row, number, type, price }],
  subtotal,
  fees,
  total
}
```

Kun asiakas painaa **Jatka tilaukseen**:

```js
{
  type: 'kivikyla-seatmap:checkout',
  eventId: 'RAHINA-MMA-DEMO',
  seats: [{ id, section, row, number, type, price }]
}
```

Vastaanottoesimerkki:

```js
window.addEventListener('message', (event) => {
  if (event.origin !== 'https://LIPPUKAUPAN-DOMAIN') return;

  if (event.data?.type === 'kivikyla-seatmap:selection') {
    console.log('Paikkavalinta muuttui', event.data);
  }

  if (event.data?.type === 'kivikyla-seatmap:checkout') {
    // Luo palvelinpuolinen väliaikainen varaus ja siirry kassalle.
  }
});
```

## Tuotantoon vietäessä

Demon hinnat ja varatut paikat ovat esimerkkidataa. Tuotantoversiossa palvelin palauttaa vähintään:

- tapahtuman tunnisteen
- katsomolohkot, rivit ja paikat
- hintaluokat
- reaaliaikaisen saatavuuden
- esteettömät paikat ja saattajapaikat
- varauksen aikakatkaisun
- allekirjoitetun varaus- tai ostoskoritunnisteen

Paikkoja ei pidä varata vain selaimessa. Lopullinen saatavuus ja varaus vahvistetaan aina palvelimella kilpailutilanteiden estämiseksi.

## Lähdeaineisto

Rakenteen lähteenä käytetty paikallista Nextcloud-aineistoa:

`/home/nabil/Nextcloud/Yritykset/Biletti/Rähinä MMA/Kivikylän Areena katsomokartat/`

Edellinen geneerinen versio on säilytetty tiedostossa `generic-v1.html`.
